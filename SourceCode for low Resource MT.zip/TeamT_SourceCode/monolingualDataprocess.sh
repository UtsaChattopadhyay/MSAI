#!/bin/bash

# Transform long options to short ones
for arg in "$@"; do
  shift
  case "$arg" in
    "--src") set -- "$@" "-s" ;;
    "--tgt") set -- "$@" "-t" ;;
    "--bpe") set -- "$@" "-b" ;;
    *)       set -- "$@" "$arg"
  esac
done

# Default behavior
rest=false; ws=false

# Parse short options
OPTIND=1

while getopts "s:t:b:" opt      # get options for -a and -b ( ':' - option has an argument )
do
    case $opt in
        s)   SRC=$OPTARG ;;
        t)   TGT=$OPTARG ;;
        b)   TRAIN_MINLEN=$OPTARG ;; # remove sentences with <6 BPE tokens
        "?") print_usage >&2; exit 1 ;;
    esac
done
shift $(expr $OPTIND - 1)

# SRC=si/ne/km/ps
TGT=en

BPESIZE=5000
# TRAIN_MINLEN=$2  # remove sentences with <6 BPE tokens
TRAIN_MAXLEN=250  # remove sentences with >250 BPE tokens

ROOT=$(dirname "$0")
SCRIPTS=$ROOT/scripts
DATA=$ROOT/data
TMP=$DATA/wiki_${SRC}_${TGT}_bpe${BPESIZE}
DATABIN=$ROOT/data-bin/wiki_${SRC}_${TGT}_bpe${BPESIZE}
mkdir -p $TMP $DATABIN

SRC_TOKENIZER="bash $SCRIPTS/indic_norm_tok.sh $SRC"
TGT_TOKENIZER="cat"  # learn target-side BPE over untokenized (raw) text
SPM_TRAIN=$SCRIPTS/spm_train.py
SPM_ENCODE=$SCRIPTS/spm_encode.py


echo "pre-processing train data..."
bash $SCRIPTS/download_indic.sh

##Path to add the monolingual data  - $DATA/mono.sample1200000.$TGT 
## A dummy source with dummy values wuth same number of lines need to be present in $DATA/mono.sample1200000.$SRC 

$SRC_TOKENIZER $DATA/mono.data.$SRC > $TMP/test.$SRC
$TGT_TOKENIZER $DATA/mono.data.$TGT > $TMP/test.$TGT


DATABIN=$ROOT/mbart.cc25.v2

for SPLIT in "test"; do \
  python $SPM_ENCODE \
    --model $DATABIN/sentence.bpe.model \
    --output_format=piece \
    --inputs $TMP/$SPLIT.$SRC $TMP/$SPLIT.$TGT \
    --outputs $TMP/$SPLIT.bpe.$SRC $TMP/$SPLIT.bpe.$TGT
done



DATABIN=$ROOT/data-bin/wiki_${SRC}_${TGT}_bpe${BPESIZE}
DICT='mbart.cc25.v2/dict.txt'
fairseq-preprocess \
  --source-lang $SRC \
  --target-lang $TGT \
  --testpref $TMP/test.bpe \
  --destdir $DATABIN \
  --thresholdtgt 0 \
  --thresholdsrc 0 \
  --srcdict ${DICT} \
  --tgtdict ${DICT} \
  --workers 70
