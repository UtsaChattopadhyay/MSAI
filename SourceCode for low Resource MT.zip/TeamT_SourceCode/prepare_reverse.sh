# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
#!/bin/bash

# Transform long options to short ones
for arg in "$@"; do
  shift
  case "$arg" in
    "--src") set -- "$@" "-s" ;;
    "--tgt") set -- "$@" "-t" ;;
    "--bpe") set -- "$@" "-b" ;;
    *)       set -- "$@" "$arg"
  esac
done

# Default behavior
rest=false; ws=false

# Parse short options
OPTIND=1

while getopts "s:t:b:" opt      # get options for -a and -b ( ':' - option has an argument )
do
    case $opt in
        s)   SRC=$OPTARG ;;
        t)   TGT=$OPTARG ;;
        b)   TRAIN_MINLEN=$OPTARG ;; # remove sentences with <6 BPE tokens
        "?") print_usage >&2; exit 1 ;;
    esac
done
shift $(expr $OPTIND - 1)

# SRC=si/ne/km/ps
# TGT=en

BPESIZE=5000
# TRAIN_MINLEN=$2  # remove sentences with <6 BPE tokens
TRAIN_MAXLEN=250  # remove sentences with >250 BPE tokens

ROOT=$(dirname "$0")
SCRIPTS=$ROOT/scripts
DATA=$ROOT/data
TMP=$DATA/wiki_${SRC}_${TGT}_bpe${BPESIZE}
DATABIN=$ROOT/data-bin/wiki_${SRC}_${TGT}_bpe${BPESIZE}
rm -rf $TMP $DATABIN
mkdir -p $TMP $DATABIN

SRC_TOKENIZER="cat"  # learn source-side BPE over untokenized (raw) text
TGT_TOKENIZER="bash $SCRIPTS/indic_norm_tok.sh $TGT"
SPM_TRAIN=$SCRIPTS/spm_train.py
SPM_ENCODE=$SCRIPTS/spm_encode.py

URLS=(
    "https://github.com/facebookresearch/flores/raw/master/data/wikipedia_en_ne_si_test_sets.tgz"
    "https://github.com/facebookresearch/flores/raw/master/data/flores_test_sets.tgz"
)
ARCHIVES=(
    "wikipedia_en_ne_si_test_sets.tgz"
    "flores_test_sets.tgz"
)

SI_TRAIN_SETS=(
    # "all-clean-si/GNOMEKDEUbuntu.en-si"
    # "all-clean-si/OpenSubtitles2018.en-si"
    "all-clean-si/train.si-en"
)
SI_VALID_SET="wikipedia_en_ne_si_test_sets/wikipedia.dev.si-en"
SI_TEST_SET="wikipedia_en_ne_si_test_sets/wikipedia.devtest.si-en"
SI_CLEAN=all-clean-si

NE_TRAIN_SETS=(  
    # "all-clean-ne/bible_dup.en-ne"  
    # "all-clean-ne/bible.en-ne"  
    # "all-clean-ne/globalvoices.2018q4.ne-en"  
    # "all-clean-ne/GNOMEKDEUbuntu.en-ne" 
    # "all-clean-ne/nepali-penn-treebank" 
    "all-clean-ne/train.ne-en"
) 
NE_VALID_SET="wikipedia_en_ne_si_test_sets/wikipedia.dev.ne-en"  
NE_TEST_SET="wikipedia_en_ne_si_test_sets/wikipedia.devtest.ne-en" 
NE_CLEAN=all-clean-ne

KM_TRAIN_SETS=(
    # "all-clean-km/GNOMEKDEUbuntu.en-km"
    # "all-clean-km/OpenSubtitles2018.en-km"
    "all-clean-km/train.km-en"
)
KM_VALID_SET="flores_test_sets/wikipedia.dev.km-en"
KM_TEST_SET="flores_test_sets/wikipedia.devtest.km-en"
KM_CLEAN=all-clean-km

PS_TRAIN_SETS=(
    # "all-clean-ps/GNOMEKDEUbuntu.en-ps"
    # "all-clean-ps/OpenSubtitles2018.en-ps"
    "all-clean-ps/train.ps-en"
)
PS_VALID_SET="flores_test_sets/wikipedia.dev.ps-en"
PS_TEST_SET="flores_test_sets/wikipedia.devtest.ps-en"
PS_CLEAN=all-clean-ps

TA_TRAIN_SETS=(
    "all-clean-ta/train.ta-en"
)
TA_VALID_SET="opus_test_sets/valid.ta-en"
TA_TEST_SET="opus_test_sets/test.ta-en"
TA_CLEAN=all-clean-ta

HI_TRAIN_SETS=(
    "all-clean-hi/train.hi-en"
)
HI_VALID_SET="opus_test_sets/valid.hi-en"
HI_TEST_SET="opus_test_sets/test.hi-en"
HI_CLEAN=all-clean-hi

VI_TRAIN_SETS=(
    "all-clean-vi/train.vi-en"
)
VI_VALID_SET="opus_test_sets/valid.vi-en"
VI_TEST_SET="opus_test_sets/test.vi-en"
VI_CLEAN=all-clean-vi

FA_TRAIN_SETS=(
    "all-clean-fa/train.fa-en"
)
FA_VALID_SET="opus_test_sets/valid.fa-en"
FA_TEST_SET="opus_test_sets/test.fa-en"
FA_CLEAN=all-clean-fa

# echo "Downloading mbart cc25 pre-trained model"
# rm -rf $ROOT/mbart.cc25.v2
# wget https://dl.fbaipublicfiles.com/fairseq/models/mbart/mbart.cc25.v2.tar.gz
# tar -xzvf mbart.cc25.v2.tar.gz
# rm -rf mbart.cc25.v2.tar.gz

# cp $ROOT/mbart.cc25.v2/dict.txt $ROOT/mbart.cc25.v2/dict.txt.bkp
# cat $DATA/dictionaries/dict*.txt >> $ROOT/mbart.cc25.v2/dict.txt

case $TGT in
  "si") TRAIN_SETS=$SI_TRAIN_SETS
        VALID_SET=$SI_VALID_SET
        TEST_SET=$SI_TEST_SET
        CLEAN=$SI_CLEAN
        ;;
  "ne") TRAIN_SETS=$NE_TRAIN_SETS
        VALID_SET=$NE_VALID_SET
        TEST_SET=$NE_TEST_SET
        CLEAN=$NE_CLEAN
        ;;
  "km") TRAIN_SETS=$KM_TRAIN_SETS
        VALID_SET=$KM_VALID_SET
        TEST_SET=$KM_TEST_SET
        CLEAN=$KM_CLEAN
        ;;
  "ps") TRAIN_SETS=$PS_TRAIN_SETS
        VALID_SET=$PS_VALID_SET
        TEST_SET=$PS_TEST_SET
        CLEAN=$PS_CLEAN
        ;;
  "ta") TRAIN_SETS=$TA_TRAIN_SETS
        VALID_SET=$TA_VALID_SET
        TEST_SET=$TA_TEST_SET
        CLEAN=$TA_CLEAN
        ;;
  "hi") TRAIN_SETS=$HI_TRAIN_SETS
        VALID_SET=$HI_VALID_SET
        TEST_SET=$HI_TEST_SET
        CLEAN=$HI_CLEAN
        ;;
  "vi") TRAIN_SETS=$VI_TRAIN_SETS
        VALID_SET=$VI_VALID_SET
        TEST_SET=$VI_TEST_SET
        CLEAN=$VI_CLEAN
        ;;
  "fa") TRAIN_SETS=$FA_TRAIN_SETS
        VALID_SET=$FA_VALID_SET
        TEST_SET=$FA_TEST_SET
        CLEAN=$FA_CLEAN
        ;;
esac

if [ ! -d $DATA/$CLEAN ]; then
    echo "Data directory not found. Please run 'bash download-data.sh' first..."
    exit -1
fi

# download and extract data
for ((i=0;i<${#URLS[@]};++i)); do
    ARCHIVE=$DATA/${ARCHIVES[i]}
    if [ -f $ARCHIVE ]; then
        echo "$ARCHIVE already exists, skipping download"
    else
        URL=${URLS[i]}
        wget -P $DATA "$URL"
        if [ -f $ARCHIVE ]; then
            echo "$URL successfully downloaded."
        else
            echo "$URL not successfully downloaded."
            exit -1
        fi
    fi
    FILE=${ARCHIVE: -4}
    if [ -e $FILE ]; then
        echo "$FILE already exists, skipping extraction"
    else
        tar -C $DATA -xzvf $ARCHIVE
    fi
done

echo "pre-processing train data..."
bash $SCRIPTS/download_indic.sh
for FILE in "${TRAIN_SETS[@]}" ; do
    $SRC_TOKENIZER $DATA/$FILE.$SRC
done > $TMP/train.$SRC
for FILE in "${TRAIN_SETS[@]}"; do
    $TGT_TOKENIZER $DATA/$FILE.$TGT
done > $TMP/train.$TGT

echo "pre-processing dev/test data..."
$SRC_TOKENIZER $DATA/${VALID_SET}.$SRC > $TMP/valid.$SRC
$TGT_TOKENIZER $DATA/${VALID_SET}.$TGT > $TMP/valid.$TGT
$SRC_TOKENIZER $DATA/${TEST_SET}.$SRC > $TMP/test.$SRC
$TGT_TOKENIZER $DATA/${TEST_SET}.$TGT > $TMP/test.$TGT

# DISABLE: learn BPE with sentencepiece
# python $SPM_TRAIN \
#   --input=$TMP/train.$SRC,$TMP/train.$TGT \
#   --model_prefix=$DATABIN/sentencepiece.bpe \
#   --vocab_size=$BPESIZE \
#   --character_coverage=1.0 \
#   --model_type=bpe

# encode train/valid/test
DATABIN=$ROOT/mbart.cc25.v2
python $SPM_ENCODE \
  --model $DATABIN/sentence.bpe.model \
  --output_format=piece \
  --inputs $TMP/train.$SRC $TMP/train.$TGT \
  --outputs $TMP/train.bpe.$SRC $TMP/train.bpe.$TGT \
  --min-len $TRAIN_MINLEN --max-len $TRAIN_MAXLEN
for SPLIT in "valid" "test"; do \
  python $SPM_ENCODE \
    --model $DATABIN/sentence.bpe.model \
    --output_format=piece \
    --inputs $TMP/$SPLIT.$SRC $TMP/$SPLIT.$TGT \
    --outputs $TMP/$SPLIT.bpe.$SRC $TMP/$SPLIT.bpe.$TGT
done

# binarize data
# fairseq-preprocess \
#   --source-lang $SRC \
#   --target-lang $TGT \
#   --trainpref $TMP/train.bpe \
#   --validpref $TMP/valid.bpe \
#   --testpref $TMP/test.bpe \
#   --destdir $DATABIN \
#   --joined-dictionary \
#   --workers 4

DATABIN=$ROOT/data-bin/wiki_${SRC}_${TGT}_bpe${BPESIZE}
DICT='mbart.cc25.v2/dict.txt'
fairseq-preprocess \
  --source-lang $SRC \
  --target-lang $TGT \
  --trainpref $TMP/train.bpe \
  --validpref $TMP/valid.bpe \
  --testpref $TMP/test.bpe \
  --destdir $DATABIN \
  --thresholdtgt 0 \
  --thresholdsrc 0 \
  --srcdict ${DICT} \
  --tgtdict ${DICT} \
  --workers 70
