# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
#
#!/bin/bash
# Downloads the data and creates data/all-clean.tgz within the current directory

set -e
set -o pipefail

SRC=en
SI_TGT=si
NE_TGT=ne
PS_TGT=ps
KM_TGT=km
HI_TGT=hi
TA_TGT=ta
VI_TGT=vi
FA_TGT=fa

ROOT=$(dirname "$0")
DATA=$ROOT/data
NE_ROOT=$DATA/all-clean-ne
SI_ROOT=$DATA/all-clean-si
KM_ROOT=$DATA/all-clean-km
PS_ROOT=$DATA/all-clean-ps
HI_ROOT=$DATA/all-clean-hi
TA_ROOT=$DATA/all-clean-ta
VI_ROOT=$DATA/all-clean-vi
FA_ROOT=$DATA/all-clean-fa
OPUS_ROOT=$DATA/opus_test_sets

mkdir -p $DATA
# mkdir -p $DATA $NE_ROOT $SI_ROOT $KM_ROOT $PS_ROOT $HI_ROOT $TA_ROOT $VI_ROOT $FA_ROOT $OPUS_ROOT

##############################################################################
#                                 DATASETS CONFIG                            #
##############################################################################
# Lang Pair: SI-EN
SI_OPUS_DATASETS=(
  "$SI_ROOT/GNOME.en-si"
  "$SI_ROOT/Ubuntu.en-si"
  "$SI_ROOT/KDE4.en-si"
  "$SI_ROOT/OpenSubtitles.en-si"
)

SI_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-si.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-si.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-si.txt.zip"
  "https://object.pouta.csc.fi/OPUS-OpenSubtitles/v2018/moses/en-si.txt.zip"
)

# Lang Pair: TA-EN
TA_OPUS_DATASETS=(
  "$TA_ROOT/GNOME.en-ta"
  "$TA_ROOT/Ubuntu.en-ta"
  "$TA_ROOT/KDE4.en-ta"
  "$TA_ROOT/OpenSubtitles.en-ta"
)

TA_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-ta.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-ta.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-ta.txt.zip"
  "https://object.pouta.csc.fi/OPUS-OpenSubtitles/v2018/moses/en-ta.txt.zip"
)

TA_OPUS_VALID_DATASETS=(
  "$OPUS_ROOT/Tanzil.en-ta"
)

TA_OPUS_VALID_URLS=(
  "https://object.pouta.csc.fi/OPUS-Tanzil/v1/moses/en-ta.txt.zip"
)

TA_OPUS_TEST_DATASETS=(
  "$OPUS_ROOT/TED2020.en-ta"
  "$OPUS_ROOT/Tatoeba.en-ta"
)

TA_OPUS_TEST_URLS=(
  "https://object.pouta.csc.fi/OPUS-TED2020/v1/moses/en-ta.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Tatoeba/v2021-03-10/moses/en-ta.txt.zip"
)

# Lang Pair: NE-EN
NE_OPUS_DATASETS=(
  "$NE_ROOT/GNOME.en-ne"
  "$NE_ROOT/Ubuntu.en-ne"
  "$NE_ROOT/KDE4.en-ne"
  "$NE_ROOT/GlobalVoices.en-ne"
)

NE_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-ne.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-ne.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-ne.txt.zip"
  "https://object.pouta.csc.fi/OPUS-GlobalVoices/v2018q4/moses/en-ne.txt.zip"
)

# Lang Pair: HI-EN
HI_OPUS_DATASETS=(
  "$HI_ROOT/GNOME.en-hi"
  "$HI_ROOT/Ubuntu.en-hi"
  "$HI_ROOT/KDE4.en-hi"
  "$HI_ROOT/Tanzil.en-hi"
  "$HI_ROOT/OpenSubtitles.en-hi"
  "$HI_ROOT/GlobalVoices.en-hi"
)

HI_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-hi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-hi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-hi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Tanzil/v1/moses/en-hi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-OpenSubtitles/v2018/moses/en-hi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-GlobalVoices/v2017q3/moses/en-hi.txt.zip"
)

HI_OPUS_VALID_DATASETS=(
  "$OPUS_ROOT/Tatoeba.en-hi"
  "$OPUS_ROOT/QED.en-hi"
)

HI_OPUS_VALID_URLS=(
  "https://object.pouta.csc.fi/OPUS-Tatoeba/v20190709/moses/en-hi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-QED/v2.0a/moses/en-hi.txt.zip"
)

HI_OPUS_TEST_DATASETS=(
  "$OPUS_ROOT/bible-uedin.en-hi"
  "$OPUS_ROOT/WMT-News.en-hi"
)

HI_OPUS_TEST_URLS=(
  "https://object.pouta.csc.fi/OPUS-bible-uedin/v1/moses/en-hi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-WMT-News/v2019/moses/en-hi.txt.zip"
)

# Lang Pair: KM-EN
KM_OPUS_DATASETS=(
  "$KM_ROOT/GNOME.en-km"
  "$KM_ROOT/Ubuntu.en-km"
  "$KM_ROOT/KDE4.en-km"
  "$KM_ROOT/GlobalVoices.en-km"
)

KM_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-km.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-km.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-km.txt.zip"
  "https://object.pouta.csc.fi/OPUS-GlobalVoices/v2018q4/moses/en-km.txt.zip"
)

# Lang Pair: VI-EN
VI_OPUS_DATASETS=(
  "$VI_ROOT/GNOME.en-vi"
  "$VI_ROOT/Ubuntu.en-vi"
  "$VI_ROOT/KDE4.en-vi"
  "$VI_ROOT/OpenSubtitles.en-vi"
)

VI_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-vi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-vi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-vi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-OpenSubtitles/v2018/moses/en-vi.txt.zip"
)

VI_OPUS_VALID_DATASETS=(
  "$OPUS_ROOT/QED.en-vi"
)

VI_OPUS_VALID_URLS=(
  "https://object.pouta.csc.fi/OPUS-QED/v2.0a/moses/en-vi.txt.zip"
)

VI_OPUS_TEST_DATASETS=(
  "$OPUS_ROOT/TED2020.en-vi"
  "$OPUS_ROOT/Wikipedia.en-vi"
)

VI_OPUS_TEST_URLS=(
  "https://object.pouta.csc.fi/OPUS-TED2020/v1/moses/en-vi.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Wikipedia/v1.0/moses/en-vi.txt.zip"
)

# Lang Pair: PS-EN
PS_OPUS_DATASETS=(
  "$PS_ROOT/GNOME.en-ps"
  "$PS_ROOT/Ubuntu.en-ps"
  "$PS_ROOT/KDE4.en-ps"
  # "$PS_ROOT/OpenSubtitles.en-ps"
)

PS_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-ps.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-ps.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-ps.txt.zip"
  # "https://object.pouta.csc.fi/OPUS-OpenSubtitles/v2018/moses/en-ps.txt.zip"
)

# Lang Pair: FA-EN
FA_OPUS_DATASETS=(
  "$FA_ROOT/GNOME.en-fa"
  "$FA_ROOT/Ubuntu.en-fa"
  "$FA_ROOT/KDE4.en-fa"
  "$FA_ROOT/OpenSubtitles.en-fa"
  "$FA_ROOT/Tanzil.en-fa"
  "$FA_ROOT/GlobalVoices.en-fa"
)

FA_OPUS_URLS=(
  "https://object.pouta.csc.fi/OPUS-GNOME/v1/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Ubuntu/v14.10/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-KDE4/v2/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-OpenSubtitles/v2018/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-Tanzil/v1/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-GlobalVoices/v2017q3/moses/en-fa.txt.zip"
)

FA_OPUS_VALID_DATASETS=(
  "$OPUS_ROOT/TEP.en-fa"
  "$OPUS_ROOT/QED.en-fa"
)

FA_OPUS_VALID_URLS=(
  "https://object.pouta.csc.fi/OPUS-TEP/v1/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-QED/v2.0a/moses/en-fa.txt.zip"
)

FA_OPUS_TEST_DATASETS=(
  "$OPUS_ROOT/Wikipedia.en-fa"
  "$OPUS_ROOT/TED2013.en-fa"
  "$OPUS_ROOT/infopankki.en-fa"
)

FA_OPUS_TEST_URLS=(
  "https://object.pouta.csc.fi/OPUS-Wikipedia/v1.0/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-TED2013/v1.1/moses/en-fa.txt.zip"
  "https://object.pouta.csc.fi/OPUS-infopankki/v1/moses/en-fa.txt.zip"
)

REMOVE_FILE_PATHS=()

# Download data
download_data() {
  CORPORA=$1
  URL=$2

  if [ -f $CORPORA ]; then
    echo "$CORPORA already exists, skipping download"
  else
    echo "Downloading $URL"
    wget $URL -O $CORPORA --no-check-certificate || rm -f $CORPORA
    if [ -f $CORPORA ]; then
      echo "$URL successfully downloaded."
    else
      echo "$URL not successfully downloaded."
      rm -f $CORPORA
      exit -1
    fi
  fi
}

# Example: download_opus_data $LANG_ROOT $TGT
download_opus_data() {
  LANG_ROOT=$1
  TGT=$2
  DS_TYPE=$3

  if [ "$DS_TYPE" = "train" ]; then
    if [ "$TGT" = "si" ]; then
      URLS=("${SI_OPUS_URLS[@]}")
      DATASETS=("${SI_OPUS_DATASETS[@]}")
    elif [ "$TGT" = "ne" ]; then
      URLS=("${NE_OPUS_URLS[@]}")
      DATASETS=("${NE_OPUS_DATASETS[@]}")
    elif [ "$TGT" = "km" ]; then
      URLS=("${KM_OPUS_URLS[@]}")
      DATASETS=("${KM_OPUS_DATASETS[@]}")
    elif [ "$TGT" = "ps" ]; then
      URLS=("${PS_OPUS_URLS[@]}")
      DATASETS=("${PS_OPUS_DATASETS[@]}")
    elif [ "$TGT" = "ta" ]; then
      URLS=("${TA_OPUS_URLS[@]}")
      DATASETS=("${TA_OPUS_DATASETS[@]}")
    elif [ "$TGT" = "hi" ]; then
      URLS=("${HI_OPUS_URLS[@]}")
      DATASETS=("${HI_OPUS_DATASETS[@]}")
    elif [ "$TGT" = "vi" ]; then
      URLS=("${VI_OPUS_URLS[@]}")
      DATASETS=("${VI_OPUS_DATASETS[@]}")
    elif [ "$TGT" = "fa" ]; then
      URLS=("${FA_OPUS_URLS[@]}")
      DATASETS=("${FA_OPUS_DATASETS[@]}")
    fi
  elif [ "$DS_TYPE" = "valid" ]; then
    if [ "$TGT" = "ta" ]; then
      URLS=("${TA_OPUS_VALID_URLS[@]}")
      DATASETS=("${TA_OPUS_VALID_DATASETS[@]}")
    elif [ "$TGT" = "hi" ]; then
      URLS=("${HI_OPUS_VALID_URLS[@]}")
      DATASETS=("${HI_OPUS_VALID_DATASETS[@]}")
    elif [ "$TGT" = "vi" ]; then
      URLS=("${VI_OPUS_VALID_URLS[@]}")
      DATASETS=("${VI_OPUS_VALID_DATASETS[@]}")
    elif [ "$TGT" = "fa" ]; then
      URLS=("${FA_OPUS_VALID_URLS[@]}")
      DATASETS=("${FA_OPUS_VALID_DATASETS[@]}")
    fi
  else
    if [ "$TGT" = "ta" ]; then
      URLS=("${TA_OPUS_TEST_URLS[@]}")
      DATASETS=("${TA_OPUS_TEST_DATASETS[@]}")
    elif [ "$TGT" = "hi" ]; then
      URLS=("${HI_OPUS_TEST_URLS[@]}")
      DATASETS=("${HI_OPUS_TEST_DATASETS[@]}")
    elif [ "$TGT" = "vi" ]; then
      URLS=("${VI_OPUS_TEST_URLS[@]}")
      DATASETS=("${VI_OPUS_TEST_DATASETS[@]}")
    elif [ "$TGT" = "fa" ]; then
      URLS=("${FA_OPUS_TEST_URLS[@]}")
      DATASETS=("${FA_OPUS_TEST_DATASETS[@]}")
    fi
  fi

  for ((i=0;i<${#URLS[@]};++i)); do
    URL=${URLS[i]}
    CORPORA=${DATASETS[i]}
    download_data $CORPORA $URL
    unzip -o $CORPORA -d $LANG_ROOT
    REMOVE_FILE_PATHS+=( $CORPORA $CORPORA.xml $CORPORA.ids $LANG_ROOT/README $LANG_ROOT/LICENSE )
    # echo "*********************************************************************************************"
    # echo "LANG ROOT:"
    # ls -l $LANG_ROOT
  done

  # cat ${DATASETS[0]}.$SRC ${DATASETS[1]}.$SRC ${DATASETS[2]}.$SRC > $LANG_ROOT/GNOMEKDEUbuntu.$SRC-$TGT.$SRC
  # cat ${DATASETS[0]}.$TGT ${DATASETS[1]}.$TGT ${DATASETS[2]}.$TGT > $LANG_ROOT/GNOMEKDEUbuntu.$SRC-$TGT.$TGT
  # echo "LINE COUNT:"
  # wc -l $LANG_ROOT/GNOMEKDEUbuntu.$SRC-$TGT.$SRC
  # wc -l $LANG_ROOT/GNOMEKDEUbuntu.$SRC-$TGT.$TGT

  # REMOVE_FILE_PATHS+=( ${DATASETS[0]}.$SRC ${DATASETS[1]}.$SRC ${DATASETS[2]}.$SRC )
  # REMOVE_FILE_PATHS+=( ${DATASETS[0]}.$TGT ${DATASETS[1]}.$TGT ${DATASETS[2]}.$TGT )

  for ((i=0;i<${#DATASETS[@]};++i)); do
    cat ${DATASETS[i]}.$SRC >> $LANG_ROOT/$DS_TYPE.$TGT-$SRC.$SRC
    cat ${DATASETS[i]}.$TGT >> $LANG_ROOT/$DS_TYPE.$TGT-$SRC.$TGT
    REMOVE_FILE_PATHS+=( ${DATASETS[i]}.xml ${DATASETS[i]}.$SRC ${DATASETS[i]}.$TGT)
  done

}

get_si_en_corpus() {
  rm -rf $SI_ROOT $TA_ROOT $OPUS_ROOT
  mkdir -p $SI_ROOT $TA_ROOT $OPUS_ROOT
  rm -rf $SI_ROOT/train.$SI_TGT-$SRC.$SRC
  download_opus_data $SI_ROOT $SI_TGT "train"
  # cp ${SI_OPUS_DATASETS[3]}.$SRC $SI_ROOT/OpenSubtitles2018.$SRC-$SI_TGT.$SRC
  # cp ${SI_OPUS_DATASETS[3]}.$SI_TGT $SI_ROOT/OpenSubtitles2018.$SRC-$SI_TGT.$SI_TGT
  # REMOVE_FILE_PATHS+=( ${SI_OPUS_DATASETS[3]}.$SRC ${SI_OPUS_DATASETS[3]}.$SI_TGT )

  # Append translated monoligual data
  # prepare-monolingual.sh
  wc -l $SI_ROOT/train.$SI_TGT-$SRC.$SI_TGT
  wc -l $SI_ROOT/train.$SI_TGT-$SRC.$SRC 

  SI_TRANSLATED_MONOLINGUAL_DATASETS=$DATA/mono/
  cat $SI_TRANSLATED_MONOLINGUAL_DATASETS/mono.$SI_TGT-$SRC.$SI_TGT >> $SI_ROOT/train.$SI_TGT-$SRC.$SI_TGT
  cat $SI_TRANSLATED_MONOLINGUAL_DATASETS/mono.$SI_TGT-$SRC.$SRC >> $SI_ROOT/train.$SI_TGT-$SRC.$SRC # translated output

  wc -l $SI_ROOT/train.$SI_TGT-$SRC.$SI_TGT
  wc -l $SI_ROOT/train.$SI_TGT-$SRC.$SRC 
}

get_km_en_corpus() {
  rm -rf $KM_ROOT $VI_ROOT $OPUS_ROOT
  mkdir -p $KM_ROOT $VI_ROOT $OPUS_ROOT
  rm -rf $KM_ROOT/train.$KM_TGT-$SRC.$SRC
  download_opus_data $KM_ROOT $KM_TGT "train"
  # cp ${KM_OPUS_DATASETS[3]}.$SRC $KM_ROOT/globalvoices.2018q4.$SRC-$KM_TGT.$SRC
  # cp ${KM_OPUS_DATASETS[3]}.$KM_TGT $KM_ROOT/globalvoices.2018q4.$SRC-$KM_TGT.$KM_TGT
  # REMOVE_FILE_PATHS+=( ${KM_OPUS_DATASETS[3]}.$SRC ${KM_OPUS_DATASETS[3]}.$KM_TGT )
  wc -l $KM_ROOT/train.$KM_TGT-$SRC.$KM_TGT
  wc -l $KM_ROOT/train.$KM_TGT-$SRC.$SRC 

  KM_TRANSLATED_MONOLINGUAL_DATASETS=$DATA/mono/
  cat $KM_TRANSLATED_MONOLINGUAL_DATASETS/mono.$KM_TGT-$SRC.$KM_TGT >> $KM_ROOT/train.$KM_TGT-$SRC.$KM_TGT
  cat $KM_TRANSLATED_MONOLINGUAL_DATASETS/mono.$KM_TGT-$SRC.$SRC >> $KM_ROOT/train.$KM_TGT-$SRC.$SRC # translated output

  wc -l $KM_ROOT/train.$KM_TGT-$SRC.$KM_TGT
  wc -l $KM_ROOT/train.$KM_TGT-$SRC.$SRC 

}

get_ps_en_corpus() {
  rm -rf $PS_ROOT $FA_ROOT $OPUS_ROOT
  mkdir -p $PS_ROOT $FA_ROOT $OPUS_ROOT
  rm -rf $PS_ROOT/train.$PS_TGT-$SRC.$SRC
  download_opus_data $PS_ROOT $PS_TGT "train"
  # cp ${PS_OPUS_DATASETS[3]}.$SRC $PS_ROOT/globalvoices.2018q4.$SRC-$PS_TGT.$SRC
  # cp ${PS_OPUS_DATASETS[3]}.$PS_TGT $PS_ROOT/globalvoices.2018q4.$SRC-$PS_TGT.$PS_TGT
  # REMOVE_FILE_PATHS+=( ${PS_OPUS_DATASETS[3]}.$SRC ${PS_OPUS_DATASETS[3]}.$PS_TGT )
  wc -l $PS_ROOT/train.$PS_TGT-$SRC.$PS_TGT
  wc -l $PS_ROOT/train.$PS_TGT-$SRC.$SRC 

  PS_TRANSLATED_MONOLINGUAL_DATASETS=$DATA/mono/
  cat $PS_TRANSLATED_MONOLINGUAL_DATASETS/mono.$PS_TGT-$SRC.$PS_TGT >> $PS_ROOT/train.$PS_TGT-$SRC.$PS_TGT
  cat $PS_TRANSLATED_MONOLINGUAL_DATASETS/mono.$PS_TGT-$SRC.$SRC >> $PS_ROOT/train.$PS_TGT-$SRC.$SRC # translated output

  wc -l $PS_ROOT/train.$PS_TGT-$SRC.$PS_TGT
  wc -l $PS_ROOT/train.$PS_TGT-$SRC.$SRC 
}

get_ne_en_corpus() {
  rm -rf $NE_ROOT $HI_ROOT $OPUS_ROOT
  mkdir -p $NE_ROOT $HI_ROOT $OPUS_ROOT
  rm -rf $NE_ROOT/train.$NE_TGT-$SRC.$SRC
  download_opus_data $NE_ROOT $NE_TGT "train"

  wc -l $NE_ROOT/train.$NE_TGT-$SRC.$NE_TGT
  wc -l $NE_ROOT/train.$NE_TGT-$SRC.$SRC 

  NE_TRANSLATED_MONOLINGUAL_DATASETS=$DATA/mono/
  cat $NE_TRANSLATED_MONOLINGUAL_DATASETS/mono.$NE_TGT-$SRC.$NE_TGT >> $NE_ROOT/train.$NE_TGT-$SRC.$NE_TGT
  cat $NE_TRANSLATED_MONOLINGUAL_DATASETS/mono.$NE_TGT-$SRC.$SRC >> $NE_ROOT/train.$NE_TGT-$SRC.$SRC # translated output

  wc -l $NE_ROOT/train.$NE_TGT-$SRC.$NE_TGT
  wc -l $NE_ROOT/train.$NE_TGT-$SRC.$SRC 

  # # Download and extract Global Voices data
  # GLOBAL_VOICES="$NE_ROOT/globalvoices.2018q4.ne-en"
  # GLOBAL_VOICES_URL="http://www.casmacat.eu/corpus/global-voices/globalvoices.ne-en.xliff.gz"
  # # "https://opus.nlpl.eu/download.php?f=GlobalVoices/v2018q4/raw/ne.zip"

  # download_data $GLOBAL_VOICES.gz $GLOBAL_VOICES_URL
  # gunzip -Nf $GLOBAL_VOICES.gz

  # sed -ne 's?.*<source>\(.*\)</source>.*?\1?p' $GLOBAL_VOICES > $GLOBAL_VOICES.$NE_TGT
  # sed -ne 's?.*<target[^>]*>\(.*\)</target>.*?\1?p' $GLOBAL_VOICES > $GLOBAL_VOICES.$SRC

  # REMOVE_FILE_PATHS+=( $GLOBAL_VOICES )
  # cp ${NE_OPUS_DATASETS[3]}.$SRC $NE_ROOT/globalvoices.2018q4.$SRC-$NE_TGT.$SRC
  # cp ${NE_OPUS_DATASETS[3]}.$NE_TGT $NE_ROOT/globalvoices.2018q4.$SRC-$NE_TGT.$NE_TGT
  # REMOVE_FILE_PATHS+=( ${NE_OPUS_DATASETS[3]}.$SRC ${NE_OPUS_DATASETS[3]}.$NE_TGT )

  # Download and extract the bible dataset
  BIBLE_TOOLS=$ROOT/bible-corpus-tools
  XML_BIBLES=$ROOT/XML_Bibles
  XML_BIBLES_DUP=$ROOT/XML_Bibles_dup


  if [ ! -e $BIBLE_TOOLS ]; then
      echo "Cloning bible-corpus-tools repository..."
      git clone https://github.com/christos-c/bible-corpus-tools.git $BIBLE_TOOLS
  fi

  mkdir -p $BIBLE_TOOLS/bin $XML_BIBLES $XML_BIBLES_DUP
  javac -cp "$BIBLE_TOOLS/lib/*" -d $BIBLE_TOOLS/bin $BIBLE_TOOLS/src/bible/readers/*.java $BIBLE_TOOLS/src/bible/*.java

  download_data $ROOT/bible.tar.gz "https://github.com/christos-c/bible-corpus/archive/refs/tags/v1.2.1.tar.gz"
  tar xvzf $ROOT/bible.tar.gz

  cp bible-corpus-1.2.1/bibles/{Greek.xml,English.xml,Nepali.xml} $XML_BIBLES/
  cp bible-corpus-1.2.1/bibles/{Greek.xml,English-WEB.xml,Nepali.xml} $XML_BIBLES_DUP/

  java -cp $BIBLE_TOOLS/lib/*:$BIBLE_TOOLS/bin bible.CreateMLBooks $XML_BIBLES
  java -cp $BIBLE_TOOLS/lib/*:$BIBLE_TOOLS/bin bible.CreateMLBooks $XML_BIBLES_DUP
  java -cp $BIBLE_TOOLS/lib/*:$BIBLE_TOOLS/bin bible.CreateVerseAlignedBooks $XML_BIBLES
  java -cp $BIBLE_TOOLS/lib/*:$BIBLE_TOOLS/bin bible.CreateVerseAlignedBooks $XML_BIBLES_DUP

  # cat $XML_BIBLES/aligned/*/English.txt > $NE_ROOT/bible.$SRC-$NE_TGT.$SRC
  # cat $XML_BIBLES/aligned/*/Nepali.txt > $NE_ROOT/bible.$SRC-$NE_TGT.$NE_TGT
  # cat $XML_BIBLES_DUP/aligned/*/English-WEB.txt > $NE_ROOT/bible_dup.$SRC-$NE_TGT.$SRC
  # cat $XML_BIBLES_DUP/aligned/*/Nepali.txt > $NE_ROOT/bible_dup.$SRC-$NE_TGT.$NE_TGT
  cat $XML_BIBLES/aligned/*/English.txt >> $NE_ROOT/train.$NE_TGT-$SRC.$SRC
  cat $XML_BIBLES/aligned/*/Nepali.txt >> $NE_ROOT/train.$NE_TGT-$SRC.$NE_TGT
  cat $XML_BIBLES_DUP/aligned/*/English-WEB.txt >> $NE_ROOT/train.$NE_TGT-$SRC.$SRC
  cat $XML_BIBLES_DUP/aligned/*/Nepali.txt >> $NE_ROOT/train.$NE_TGT-$SRC.$NE_TGT
  REMOVE_FILE_PATHS+=( bible-corpus-1.2.1 bible.tar.gz $BIBLE_TOOLS $XML_BIBLES $XML_BIBLES_DUP )

  # Download and extract the Penn Treebank dataset
  NE_TAGGED=$ROOT/new_submissions_parallel_corpus_project_Nepal
  NE_TAGGED_URL="http://www.cle.org.pk/Downloads/ling_resources/parallelcorpus/NepaliTaggedCorpus.zip"
  EN_TAGGED_PATCH_URL="https://dl.fbaipublicfiles.com/fairseq/data/nepali-penn-treebank.en.patch"
  NE_TAGGED_PATCH_URL="https://dl.fbaipublicfiles.com/fairseq/data/nepali-penn-treebank.ne.patch"
  MOSES=$ROOT/mosesdecoder
  MOSES_TOK=$MOSES/scripts/tokenizer
  EN_PATCH_REGEX="{s:\\\/:\/:g;s/\*\T\*\-\n+//g;s/\-LCB\-/\{/g;s/\-RCB\-/\}/g; s/\-LSB\-/\[/g; s/\-RSB\-/\]/g;s/\-LRB\-/\(/g; s/\-RRB\-/\)/g; s/\'\'/\"/g; s/\`\`/\"/g; s/\ +\'s\ +/\'s /g; s/\ +\'re\ +/\'re /g; s/\"\ +/\"/g; s/\ +\"/\"/g; s/\ n't([\ \.\"])/n't\1/g; s/\r+(.)/\1/g;}"
  NE_PATCH_REGEX="{s:\p{Cf}::g;s:\\\/:\/:g;s/\*\T\*\-\n+//g;s/\-LCB\-/\{/g;s/\-RCB\-/\}/g; s/\-LSB\-/\[/g; s/\-RSB\-/\]/g;s/\-LRB\-/\(/g; s/\-RRB\-/\)/g; s/\'\'/\"/g; s/\`\`/\"/g; s/\ +\'s\ +/\'s /g; s/\ +\'re\ +/\'re /g; s/\"\ +/\"/g; s/\ +\"/\"/g; s/\ n't([\ \.\"])/n't\1/g; s/\r+(.)/\1/g;}"

  download_data $DATA/nepali-penn-treebank.$SRC.patch $EN_TAGGED_PATCH_URL
  download_data $DATA/nepali-penn-treebank.$NE_TGT.patch $NE_TAGGED_PATCH_URL
  download_data original.zip $NE_TAGGED_URL
  unzip -o original.zip -d $ROOT

  cat $NE_TAGGED/00.txt $NE_TAGGED/01.txt $NE_TAGGED/02.txt > $NE_TAGGED/nepali-penn-treebank.$SRC
  cat $NE_TAGGED/00ne_revised.txt $NE_TAGGED/01ne_revised.txt $NE_TAGGED/02ne_revised.txt > $NE_TAGGED/nepali-penn-treebank.$NE_TGT

  patch $NE_TAGGED/nepali-penn-treebank.$SRC -i $DATA/nepali-penn-treebank.$SRC.patch -o $NE_TAGGED/nepali-penn-treebank-patched.$SRC
  patch $NE_TAGGED/nepali-penn-treebank.$NE_TGT -i $DATA/nepali-penn-treebank.$NE_TGT.patch -o $NE_TAGGED/nepali-penn-treebank-patched.$NE_TGT

  if [ ! -e $MOSES ]; then
      echo "Cloning moses repository..."
      git clone https://github.com/moses-smt/mosesdecoder.git $MOSES
  fi

  cat $NE_TAGGED/nepali-penn-treebank-patched.$SRC | \
    perl -anpe "$EN_PATCH_REGEX"  | \
    $MOSES_TOK/tokenizer.perl -l $SRC | \
    $MOSES_TOK/detokenizer.perl -l $SRC >> $NE_ROOT/train.$NE_TGT-$SRC.$SRC
    # $MOSES_TOK/detokenizer.perl -l $SRC > $NE_ROOT/nepali-penn-treebank.$SRC

  cat $NE_TAGGED/nepali-penn-treebank-patched.$NE_TGT | \
    perl -CIO -anpe "$NE_PATCH_REGEX" | \
    $MOSES_TOK/detokenizer.perl -l $SRC >> $NE_ROOT/train.$NE_TGT-$SRC.$NE_TGT
    # $MOSES_TOK/detokenizer.perl -l $SRC > $NE_ROOT/nepali-penn-treebank.$NE_TGT

  # Download test sets
  download_data $DATA/wikipedia_en_ne_si_test_sets.tgz "https://github.com/facebookresearch/flores/raw/master/data/wikipedia_en_ne_si_test_sets.tgz"
  REMOVE_FILE_PATHS+=( $MOSES $NE_TAGGED original.zip $DATA/nepali-penn-treebank.$SRC.patch $DATA/nepali-penn-treebank.$NE_TGT.patch )

  pushd $DATA/
  tar -vxf wikipedia_en_ne_si_test_sets.tgz
  popd
}

get_dictionaries() {
  # Download nepali dictionary data
  DICT=$DATA/dictionaries
  TMP=$DATA/tmp/dictionaries
  mkdir -p $DATA/tmp $DATA/dictionaries
  wget "http://www.seas.upenn.edu/~nlp/resources/TACL-data-release/dictionaries.tar.gz" -O $TMP --no-check-certificate || rm -f $TMP
  tar xvzf $TMP
  # cp dictionaries/dict.si $DICT/dict.$SI_TGT-$SRC.txt
  cp dictionaries/dict.ne $DICT/dict.$NE_TGT-$SRC.txt
  # cp dictionaries/dict.km $DICT/dict.$KM_TGT-$SRC.txt
  cp dictionaries/dict.ps $DICT/dict.$PS_TGT-$SRC.txt
  cp dictionaries/dict.hi $DICT/dict.$HI_TGT-$SRC.txt
  cp dictionaries/dict.vi $DICT/dict.$VI_TGT-$SRC.txt
  cp dictionaries/dict.fa $DICT/dict.$FA_TGT-$SRC.txt
  cp dictionaries/dict.ta $DICT/dict.$TA_TGT-$SRC.txt
  REMOVE_FILE_PATHS+=( $TMP $DATA/tmp dictionaries)
}

get_ta_en_corpus() {
  rm -rf $TA_ROOT/train.$TA_TGT-$SRC.$SRC
  download_opus_data $TA_ROOT $TA_TGT "train"
  rm -rf $OPUS_ROOT/valid.$TA_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $TA_TGT "valid"
  rm -rf $OPUS_ROOT/test.$TA_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $TA_TGT "test"
}

get_vi_en_corpus() {
  rm -rf $VI_ROOT/train.$VI_TGT-$SRC.$SRC
  download_opus_data $VI_ROOT $VI_TGT "train"
  rm -rf $OPUS_ROOT/valid.$VI_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $VI_TGT "valid"
  rm -rf $OPUS_ROOT/test.$VI_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $VI_TGT "test"
}

get_fa_en_corpus() {
  rm -rf $FA_ROOT/train.$FA_TGT-$SRC.$SRC
  download_opus_data $FA_ROOT $FA_TGT "train"
  rm -rf $OPUS_ROOT/valid.$FA_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $FA_TGT "valid"
  rm -rf $OPUS_ROOT/test.$FA_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $FA_TGT "test"
}

get_hi_en_corpus() {
  rm -rf $HI_ROOT/train.$HI_TGT-$SRC.$SRC
  download_opus_data $HI_ROOT $HI_TGT "train"
  rm -rf $OPUS_ROOT/valid.$HI_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $HI_TGT "valid"
  rm -rf $OPUS_ROOT/test.$HI_TGT-$SRC.$SRC
  download_opus_data $OPUS_ROOT $HI_TGT "test"
  # Download parallel en-hi corpus
  download_data $DATA/hi-en.tgz "http://www.cfilt.iitb.ac.in/iitb_parallel/iitb_corpus_download/parallel.tgz"
  #download_data $DATA/hi-en.tgz "https://www.cse.iitb.ac.in/~anoopk/share/iitb_en_hi_parallel/iitb_corpus_download/parallel.tgz"
  tar xvzf $DATA/hi-en.tgz
  cp parallel/* $HI_ROOT/
  cat $HI_ROOT/IITB.$SRC-$HI_TGT.$HI_TGT >> $HI_ROOT/train.$HI_TGT-$SRC.$HI_TGT
  cat $HI_ROOT/IITB.$SRC-$HI_TGT.$SRC >> $HI_ROOT/train.$HI_TGT-$SRC.$SRC
  REMOVE_FILE_PATHS+=( parallel $DATA/hi-en.tgz $HI_ROOT/IITB.$SRC-$HI_TGT.$HI_TGT $HI_ROOT/IITB.$SRC-$HI_TGT.$SRC )
}

cleanup() {
  # Remove the temporary files
  for ((i=0;i<${#REMOVE_FILE_PATHS[@]};++i)); do
    rm -rf ${REMOVE_FILE_PATHS[i]}
  done
}

for arg in "$@"; do
  shift
  case "$arg" in
    "--langs") set -- "$@" "-l" ;;
    *)       set -- "$@" "$arg"
  esac
done

# Default behavior
rest=false; ws=false

# Parse short options
OPTIND=1

while getopts "l:" opt      # get options for -a and -b ( ':' - option has an argument )
do
    case $opt in
        l)   LANGS=$OPTARG ;;
        "?") print_usage >&2; exit 1 ;;
    esac
done
shift $(expr $OPTIND - 1)


case $LANGS in
  "si-en") get_si_en_corpus
           get_ta_en_corpus
           ;;
  "ne-en") get_ne_en_corpus
           get_hi_en_corpus
           ;;
  "ps-en") get_ps_en_corpus
           get_fa_en_corpus
           ;;
  "km-en") get_km_en_corpus
           get_vi_en_corpus
           ;;
esac
get_dictionaries
cleanup
