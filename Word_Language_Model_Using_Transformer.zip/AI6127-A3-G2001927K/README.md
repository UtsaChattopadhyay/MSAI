# Word-level language modeling
To run the first ipynb, which is Nlp_Ass3_Q1a.ipynb, no additional library is used other than torch and can be easily run 
by running the cells.
Explanation of sample output for Q1 a:
Output: There are 2102784 (2.10 million) parameters in this neural network and i = 1.
Parameters used were: N=1, d_model=512, nheads=8, dim_feedforward=1024
Q)Now increase the number of layers one by one up to 12 and show how the number of 
parameters increases compared to the number of layers N.
Output:
There are 2102784 (2.10 million) parameters in this neural network and i = 1
There are 4205568 (4.21 million) parameters in this neural network and i = 2
There are 6308352 (6.31 million) parameters in this neural network and i = 3
There are 8411136 (8.41 million) parameters in this neural network and i = 4
There are 10513920 (10.51 million) parameters in this neural network and i = 5
There are 12616704 (12.62 million) parameters in this neural network and i = 6
There are 14719488 (14.72 million) parameters in this neural network and i = 7
There are 16822272 (16.82 million) parameters in this neural network and i = 8
There are 18925056 (18.93 million) parameters in this neural network and i = 9
There are 21027840 (21.03 million) parameters in this neural network and i = 10
There are 23130624 (23.13 million) parameters in this neural network and i = 11
There are 25233408 (25.23 million) parameters in this neural network and i = 12
Increasing the number of layers from 1 to 12, we can observe there are significant change in 
the number of parameters. While N=1 was 2.10 million, N=12 is 25.23 million and i in the 
output represents N.

Q)For each of the previous calculations, increase the token representation size of dmodel from 
512 to 1024 and 2048, and show how the number of parameters increases compared to 
the number of layers.
Output:
Dmodel =1024, other hyperparameters same, N=1 to 12
There are 6301696 (6.30 million) parameters in this neural network and i = 1
There are 12603392 (12.60 million) parameters in this neural network and i = 2
There are 18905088 (18.91 million) parameters in this neural network and i = 3
There are 25206784 (25.21 million) parameters in this neural network and i = 4
There are 31508480 (31.51 million) parameters in this neural network and i = 5
There are 37810176 (37.81 million) parameters in this neural network and i = 6
There are 44111872 (44.11 million) parameters in this neural network and i = 7
There are 50413568 (50.41 million) parameters in this neural network and i = 8
There are 56715264 (56.72 million) parameters in this neural network and i = 9
There are 63016960 (63.02 million) parameters in this neural network and i = 10
There are 69318656 (69.32 million) parameters in this neural network and i = 11
There are 75620352 (75.62 million) parameters in this neural network and i = 12
Dmodel =2048, other hyperparameters same, N=1 to 12
There are 20990976 (20.99 million) parameters in this neural network and i = 1
There are 41981952 (41.98 million) parameters in this neural network and i = 2
There are 62972928 (62.97 million) parameters in this neural network and i = 3
There are 83963904 (83.96 million) parameters in this neural network and i = 4
There are 104954880 (104.95 million) parameters in this neural network and i = 5
There are 125945856 (125.95 million) parameters in this neural network and i = 6
There are 146936832 (146.94 million) parameters in this neural network and i = 7
There are 167927808 (167.93 million) parameters in this neural network and i = 8
There are 188918784 (188.92 million) parameters in this neural network and i = 9
There are 209909760 (209.91 million) parameters in this neural network and i = 10
There are 230900736 (230.90 million) parameters in this neural network and i = 11
There are 251891712 (251.89 million) parameters in this neural network and i = 12
Increasing the token representation size of dmodel from 512 in the previous question to 1024 
and 2048, we can observe there are significant change in the number of parameters. While 
dmodel=512 was 2.10 million for N=1, dmodel =1024 gave 6.3 million parameters for N=1 and 
dmodel= 2048 gave 20.99 million parameters for N=1, i in the output represents N.

The rest of the README is for the second ipynb, which is Nlp_Ass3_Q1e.ipynb:
We need to upload the SourceCode (source codes- main.py,model.py,data.py) folder into drive (attached) and 
cd into that (if we are using colab).
```bash 
%cd /content/drive/MyDrive/SourceCode/
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5  # Train a Transformer model on Wikitext-2 with CUDA
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5 --nlayers 6 --emsize 512 --nhead 8 --nhid 1024 
# trains a transformer model on the default transformer architecture 
# as mentioned in the paper
```
#All the instructions about which model to run can be found in the ipynb attached

The code will automatically use the cuDNN backend if run on CUDA with cuDNN installed.

During training, if a keyboard interrupt (Ctrl-C) is received,
training is stopped and the current model is evaluated against the test dataset.

The `main.py` script accepts the following arguments:

```bash
optional arguments:
  -h, --help            show this help message and exit
  --data DATA           location of the data corpus
  --model MODEL         Which model to use
  --emsize EMSIZE       embedding dimension or dmodel
  --nhid NHID           the dimension of the feedforward network model in nn.TransformerEncoder
  --nlayers NLAYERS     the number of nn.TransformerEncoderLayer in nn.TransformerEncoder
  --lr LR               initial learning rate
  --clip CLIP           gradient clipping
  --epochs EPOCHS       upper epoch limit
  --batch_size N        batch size
  --bptt BPTT           sequence length
  --dropout DROPOUT     dropout applied to layers (0 = no dropout)
  --tied                tie the word embedding and softmax weights
  --seed SEED           random seed
  --cuda                use CUDA
  --log-interval N      report interval
  --save SAVE           path to save the final model
  --onnx-export ONNX_EXPORT
                        path to export the final model in onnx format
  --nhead NHEAD         the number of heads in the multiheadattention models
```

With these arguments, a variety of models can be tested.
Explanation of sample output for Q1 e:
Q)Train the word language model with wikitext (data is given in the repository). Train the 
model for 10 epochs. Select the best model based on development set perplexity. Report 
the perplexity of the test set.
Following the implementation of [2].
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5
This gave a perplexity of 276.33 on test set. The best model on development set perplexity 
was taken.
| end of epoch 10 | time: 61.14s | valid loss 5.72 | valid ppl 303.79
==========================================================================
| End of training | test loss 5.62 | test ppl 276.33
==========================================================================
The default value as given in the github repo was taken (Arguments in main.py). Only the 
learning rate and epoch was changed to 5 and 10 respectively, using cuda and model 
transformer.


Q)You may perform hyper-parameter search on the model based on the hyper-parameters 
(N, dmodel, h, dk, ffn_dim) discussed above in the assignment.! python3 main.py --cuda --epochs 10 --model Transformer --lr 5 --nlayers 6 --emsize 512 --
nhead 8 --nhid 1024
This gave a perplexity of 280.95.
| end of epoch 10 | time: 168.93s | valid loss 5.74 | valid ppl 312.36
==========================================================================
| End of training | test loss 5.64 | test ppl 280.95
==========================================================================
The default transformer values were used as mentioned in [1], like Number of layers, N = 6,
feature dimension for each token, dmodel = 512, Number of heads, h = 8, Key and value 
representation size, dk = dmodel, h = 64, hidden representation size of the feed-forward 
layer, ffn_dim = 1024.
This part of code took 27min to run in cuda, colab gpu.
Changed hyperparameter: d_model = 1024 and remaining is same. It gave a perplexity of 
300.80.
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5 --nlayers 6 -- emsize 1024 --
nhead 8 --nhid 1024
| end of epoch 10 | time: 673.81s | valid loss 5.80 | valid ppl 331.09
==========================================================================
| End of training | test loss 5.71 | test ppl 300.80
It took 2hr 5mins to run in the same configuration with just the change in dmodel to 1024, 
which means the change in parameter size is significantly affecting but the output perplexity 
got reduced.
Changed hyperparameter: d_model = 2048 and remaining is same. It gave a perplexity of 
319.63.
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5 --nlayers 6 -- emsize 2048 --
nhead 8 --nhid 1024
| end of epoch 10 | time: 871.45s | valid loss 5.86 | valid ppl 351.64
==========================================================================
| End of training | test loss 5.77 | test ppl 319.63
It took 2hr 26mins to run in the same configuration with just the change in dmodel to 2048, 
which means the change in parameter size is significantly affecting but the output perplexity got reduced and we can notice, for the above three changes, it got worse when we increased 
the dmodel from 512 to 1024 to 2048.
Changed hyperparameter: Fn_feed_forward = 2048 and remaining is same. It gave a 
perplexity of 290.87.
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5 --nlayers 6 --emsize 512 --
nhead 8 --nhid 2048
| end of epoch 10 | time: 247.45s | valid loss 5.78 | valid ppl 324.89
==========================================================================
| End of training | test loss 5.67 | test ppl 290.87
Changing the ffn_dim to 2048 from 1024 didn’t give much change in the test set perplexity 
and we can say its not affecting the model so much.
Changed hyperparameter: N=12 and remaining is same. It gave a perplexity of 998.60.
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5 --nlayers 12 --emsize 512 --
nhead 8 --nhid 1024
| end of epoch 10 | time: 310.83s | valid loss 6.99 | valid ppl 1082.88
==========================================================================
| End of training | test loss 6.91 | test ppl 998.60
Changing the number of layers to 12 from 6 didn’t help us getting a better results since the 
change in number of parameter is huge and for only 10 epochs it is not possible for it to start 
converging. With a bigger architecture, the possibility that the model will perform better if 
we can train for more epochs.


Q)What happens when you do not perform scaling (no sqrt(dk) in the softmax in equation 1 
in [12]) in the attention head? Report the effect of scaling on perplexity.
!python3 main.py --cuda --epochs 10 --model Transformer --lr 5 --nlayers 6 --emsize 512 --
nhead 8 --nhid 1024
The part of code in the model.py (attached) attention function is changed to achieve this 
result.
#scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k)
scores = torch.matmul(query, key.transpose(-2, -1)) / 1
The perplexity became worse as the training went by and reached close to 967 on the 
validation set. Taking the best trained model, it gave a test set perplexity of 374.16.
| end of epoch 10 | time: 164.19s | valid loss 6.87 | valid ppl 966.52==========================================================================
| End of training | test loss 5.92 | test ppl 374.16
So, we can say that the scaling factor is important for the training of the transformer model 
as without it the model performance worsened. Additive attention outperforms dot product 
attention without scaling for larger values of dk. Dot products grow large in magnitude, 
pushing the softmax function into regions where it has extremely small gradients. To 
counteract this effect, scale the dot products by 1/√dk. So, the perplexity we got was also 
not good.
