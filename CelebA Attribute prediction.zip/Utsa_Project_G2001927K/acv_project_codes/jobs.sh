#!/bin/bash
#SBATCH --partition=SCSEGPU_MSAI
#SBATCH --qos=q_msai
#SBATCH --nodes=1
#SBATCH --gres=gpu:1
#SBATCH --mem=8000M
#SBATCH --job-name=TestJobACV
#SBATCH --output=test.out
#SBATCH --error=testError.err

source activate deeplearn_course
python main.py
