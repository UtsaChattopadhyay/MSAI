import os
from os import listdir
import shutil
with open('anno.txt') as f1:
    lines=f1.read().splitlines()
with open('anno1.txt') as f2:
    lists=f2.read().splitlines()
with open('prediction.txt','a') as f3:
    for i in range(len(lines)):
        f3.writelines(lines[i]+" "+((lists[i].replace(',',''))+'\n')
f1.close()
f2.close()
f3.close()