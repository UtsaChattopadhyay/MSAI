# ACV Project 1

## Acknowledgements

Majority of the codebase was taken from https://github.com/d-li14/face-attribute-prediction. I have included the original README of the github repo below.

## Directory structure

Note that there are other miscellaneous files in the directory but I have not included them in the dierctory structure explanation as they are either not used in the project or used for some minor changes

root directory structure

```
+-- acv_project_codes - contains the code for the project
+-- README.txt
+-- Requirements.txt- contains the libraries installed for the code to run and the specific version
+-- AI6126 Project 1 CelebA Facial Attribute Recognition Challenge.pdf
```

./acv_project_codes structure

```
+-- job.sh - to run the code on school server
+-- celeba.py - custom loaders for the dataset
+-- main.py - to run the model
+-- models
|   +-- resnet.py - initialize resnet
+-- utils
|   +-- eval.py
|   +-- logger.py
|   +-- misc.py
|   +-- visualize.py
+-- anno.txt - image attributes for test set
+-- train_attr_list.txt - image attributes for train set
+-- valid_attr_list.txt - image attributes for validation set
+-- prediction.txt the predicted output that is to be submitted
```

./Pre processing codes

```
+-- list_attr_celeba.txt
+-- list_eval_partition.txt
+-- img_name.txt - contains all the image names in testset_formatted
+-- test_attr_list.txt - image attributes for test set
+-- train_attr_list.txt - image attributes for train set
+-- valid_attr_list.txt - image attributes for validation set
+-- split_files.ipynb - to create the above three text files from list_attr_celeba.txt and list_eval_partition.txt
+-- directory.ipynb - to flatten the testset data to one folder and create the anno.txt file containing the image names
						for e.g.- +-- testset - test set in original format
										|   +-- Aaron_Eckhart
										|   |   +-- Aaron_Eckhart_0001.jpg
										|   |   +-- ...
								  +-- testset_formatted - test set flattened
										|   +-- Aaron_Eckhart_0001.jpg	
										|   +-- ...

```

To train the model:
python main.py

To test on the test set add 'resume=checkpoints/checkpoint.path.tar -e' to the command above.

`job.sh` - this file was used to run `main.py` on the school's server.

Running the model will create a `checkpoints` directory in the root folder that contains all the model's chackpoints along with `test.out` (contains all the print statements on `main.py`) and `testError.err` (contains all errors fro running the model)


`prediction.py` - this file merges the outputs of the model prediction (anno1.txt) with the image file names (anno.txt) into the format stated on the assignment handout. It generates prediction.txt

---

# Original README

# face-attribute-prediction

Face Attribute Prediction on [CelebA](http://mmlab.ie.cuhk.edu.hk/projects/CelebA.html) benchmark with PyTorch Implemantation, heavily borrowed from [my MobileNetV2 implementation](https://github.com/d-li14/mobilenetv2.pytorch).

## Dependencies

-   Anaconda3 (Python 3.6+, with Numpy etc.)
-   PyTorch 0.4+

## Dataset

[CelebA](http://mmlab.ie.cuhk.edu.hk/projects/CelebA.html) dataset is a large-scale face dataset with attribute-based annotations. Cropped and aligned face regions are utilized as the training source. For the pre-processed data and specific split, please feel free to contact me: <d-li14@mails.tsighua.edu.cn>

## Features

-   Both ResNet and MobileNet as the backbone for scalability
-   Each of the 40 annotated attributes predicted with multi-head networks
-   Achieve ~92% average accuracy, comparative to state-of-the-art
-   Fast convergence (5~10 epochs) through finetuning the ImageNet pre-trained models

---
