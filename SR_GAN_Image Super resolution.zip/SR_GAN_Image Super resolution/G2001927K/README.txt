Acknowledgements:
This project was completed with BasicSR (https://github.com/xinntao/BasicSR). To install and get started with BasicSR, you can refer to https://github.com/xinntao/BasicSR/blob/master/README.md along with the docs (https://github.com/xinntao/BasicSR/tree/master/docs) for more information.


Directory Structure:
Although there are many files and subdirectories, we are only interested in the following

+ — test.py-- To test the model
+ — train.py-- To train the model
+ — experiments(CHECKPOINT)
|	+ — 001_MSRResNET_x4_f64b16_DIV2K_1000k_B16G1_wandb
|	|	+ — models
|	|	|	+ — net_g_1000000.pth
|	|	+ — training_states
|	|	|	+ — 1000000.state
+ — options
|	+ — test
|	|	+ — SRResNet_SRGAN
|	|	|	+ — train_MSRResNet_x4.yml
|	+ — train
|	|	+ — SRResNet_SRGAN
|	|	|	+ — test_MSRResNet_x4_wogt.yml
+ — scripts
|	+ — extract_subimages.py

Preprocessing:
extract_subimages.py was used for preprocessing purposes. Update the paths to the datasets on the file then simply run
python3 extract_subimages.py 
This will generate new data directories (specified in the file) with the sub images.

Modifications to the model:
We are using train_MSRResNet_x4.yml to make modifications to the MSResNet model provided by BasicSR. I have changed the number of blocks (num_block on line 52) from 16 to 20.
For faster training, I also updated the number of workers (num_worker_per_gpy on line 13) from 6 to 20.

Need to run the jobs.sh file for both train and test

To train:
python3 -u BasicSR/train.py -opt BasicSR/options/train/SRResNet_SRGAN/train_MSRResNet_x4.yml

Options to the model can be modified on the train_MSRResNet_x4.yml file. To continue training from a saved checkpoint, change resume_state (Line 59) to the saved state file. For example, to load from checkpoint 5000, update resume_state: ~ to resume_state: 5000.state

To test:
python3 -u BasicSR/test.py -opt BasicSR/options/test/SRResNet_SRGAN/test_MSRResNet_x4_wogt.yml

We need to give the best path from models/net_g_x.pth in the test_MSRResNet_x4_wogt.yml path option

Helper files:
setup.py to be run as mentioned in the original basicsr readme