# GENERATED VERSION FILE
# TIME: Wed Nov 11 16:18:18 2020
__version__ = '1.1.1+unknown'
short_version = '1.1.1'
version_info = (1, 1, 1)
